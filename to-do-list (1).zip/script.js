document.getElementById('add-task-btn').addEventListener('click', function() {
  let taskInput = document.getElementById('task-input');
  let taskText = taskInput.value.trim();

  if (taskText !== "") {
    let taskList = document.getElementById('task-list');
    let newTask = document.createElement('li');

    // Add the task text
    newTask.textContent = taskText;

    // Add "Mark as completed" functionality
    newTask.addEventListener('click', function() {
      newTask.classList.toggle('completed');
    });

    // Add a remove button to the task
    let removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.classList.add('remove-btn');
    removeButton.addEventListener('click', function() {
      taskList.removeChild(newTask);
    });

    // Append the remove button to the task
    newTask.appendChild(removeButton);

    // Add the task to the list
    taskList.appendChild(newTask);

    // Clear the input field
    taskInput.value = "";
  }
});
